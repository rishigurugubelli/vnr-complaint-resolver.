import React from 'react';
import { Complaint, Severity } from '../types';

interface ComplaintItemProps {
  complaint: Complaint;
}

const severityStyles: Record<Severity, string> = {
  [Severity.HIGH]: 'bg-red-100 text-red-700 border-red-200',
  [Severity.MEDIUM]: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  [Severity.LOW]: 'bg-green-100 text-green-700 border-green-200',
};

const ComplaintItem: React.FC<ComplaintItemProps> = ({ complaint }) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg border border-slate-200 hover:shadow-xl hover:border-green-400 transition-all duration-300">
      <div className="flex justify-between items-start mb-4">
        <div>
          <p className="text-lg font-semibold text-slate-900">{complaint.name}</p>
          <p className="text-sm text-slate-500 mt-1">Roll No: {complaint.rollNumber}</p>
          <p className="text-sm text-slate-500">{complaint.email}</p>
          <p className="text-sm text-slate-500">Phone: {complaint.phoneNumber}</p>
        </div>
        <div className="text-right">
            <span className={`px-3 py-1 text-xs font-bold rounded-full border ${severityStyles[complaint.severity]}`}>
                {complaint.severity}
            </span>
        </div>
      </div>
      <p className="text-slate-700 mb-4">{complaint.description}</p>
      <div className="flex justify-between items-end text-sm text-slate-500 pt-4 border-t border-slate-200">
        <div>
            <span className="font-semibold text-slate-600">AI Category:</span>
            <span className="ml-2 inline-block bg-slate-200 text-slate-700 px-2 py-1 rounded-md text-xs font-medium">
                {complaint.category}
            </span>
        </div>
        <span>{complaint.submittedAt.toLocaleDateString()}</span>
      </div>
    </div>
  );
};

export default ComplaintItem;