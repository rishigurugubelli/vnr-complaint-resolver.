
import React from 'react';
import { CheckCircleIcon } from './icons';

interface ThankYouMessageProps {
  onReset: () => void;
}

const ThankYouMessage: React.FC<ThankYouMessageProps> = ({ onReset }) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-xl border border-slate-200 w-full max-w-2xl mx-auto text-center">
      <CheckCircleIcon className="h-16 w-16 text-green-500 mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-slate-900 mb-2">Your response has been submitted.</h2>
      <p className="text-slate-600 mb-8">Thank you!</p>
      <button
        onClick={onReset}
        className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white focus:ring-green-500 transition-all duration-300"
      >
        Submit Another Response
      </button>
    </div>
  );
};

export default ThankYouMessage;
