import React, { useState } from 'react';
import { FormData } from '../types';
import Loader from './Loader';
import { SendIcon } from './icons';

interface ComplaintFormProps {
  onRegister: (data: FormData) => void;
  isLoading: boolean;
}

const ComplaintForm: React.FC<ComplaintFormProps> = ({ onRegister, isLoading }) => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    rollNumber: '',
    email: '',
    phoneNumber: '',
    description: '',
  });
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.rollNumber || !formData.email || !formData.phoneNumber || !formData.description) {
      setError('Please fill out all fields.');
      return;
    }
    setError(null);
    onRegister(formData);
    setFormData({ name: '', rollNumber: '', email: '', phoneNumber: '', description: '' });
  };

  return (
    <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-xl border border-slate-200 w-full max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">Register a New Complaint</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-slate-600 mb-1">Full Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="w-full px-4 py-2 bg-slate-100 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-shadow text-slate-900 placeholder-slate-400"
              placeholder="e.g., John Doe"
            />
          </div>
           <div>
            <label htmlFor="rollNumber" className="block text-sm font-medium text-slate-600 mb-1">Roll Number</label>
            <input
              type="text"
              id="rollNumber"
              name="rollNumber"
              value={formData.rollNumber}
              onChange={handleChange}
              className="w-full px-4 py-2 bg-slate-100 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-shadow text-slate-900 placeholder-slate-400"
              placeholder="e.g., 21B01A0501"
            />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-600 mb-1">Email Address</label>
                <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-100 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-shadow text-slate-900 placeholder-slate-400"
                placeholder="e.g., john.doe@example.com"
                />
            </div>
            <div>
                <label htmlFor="phoneNumber" className="block text-sm font-medium text-slate-600 mb-1">Phone Number</label>
                <input
                type="tel"
                id="phoneNumber"
                name="phoneNumber"
                value={formData.phoneNumber}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-100 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-shadow text-slate-900 placeholder-slate-400"
                placeholder="e.g., 9876543210"
                />
            </div>
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-slate-600 mb-1">Complaint Details</label>
          <textarea
            id="description"
            name="description"
            rows={5}
            value={formData.description}
            onChange={handleChange}
            className="w-full px-4 py-2 bg-slate-100 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-shadow text-slate-900 placeholder-slate-400"
            placeholder="Please describe the issue in detail..."
          />
        </div>
        {error && <p className="text-red-600 text-sm">{error}</p>}
        <div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex justify-center items-center gap-2 bg-green-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white focus:ring-green-500 transition-all duration-300 disabled:bg-slate-400 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <Loader text="AI is Analyzing..." />
            ) : (
              <>
                <SendIcon className="h-5 w-5" />
                Submit Complaint
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ComplaintForm;