import React from 'react';
import { Complaint } from '../types';
import ComplaintItem from './ComplaintItem';
import { AlertTriangleIcon, DownloadIcon } from './icons';

interface ComplaintListProps {
  complaints: Complaint[];
  onExportCSV: () => void;
}

const ComplaintList: React.FC<ComplaintListProps> = ({ complaints, onExportCSV }) => {
  if (complaints.length === 0) {
    return (
      <div className="text-center py-16 px-6 bg-white/60 rounded-2xl border-2 border-dashed border-slate-300 mt-12">
        <AlertTriangleIcon className="mx-auto h-12 w-12 text-slate-400" />
        <h3 className="mt-4 text-lg font-semibold text-slate-700">No Complaints Yet</h3>
        <p className="mt-1 text-sm text-slate-500">
          Fill out the form above to register your first complaint.
        </p>
      </div>
    );
  }

  return (
    <div className="mt-12">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-green-900">Registered Complaints</h2>
        <button
          onClick={onExportCSV}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white text-sm font-semibold rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-green-200 focus:ring-green-500 transition-colors"
          aria-label="Download complaints as CSV"
        >
          <DownloadIcon className="h-4 w-4" />
          Export CSV
        </button>
      </div>
      <div className="space-y-6">
        {complaints.map((complaint) => (
          <ComplaintItem key={complaint.id} complaint={complaint} />
        ))}
      </div>
    </div>
  );
};

export default ComplaintList;