
import React from 'react';

const Loader: React.FC<{ text?: string }> = ({ text = 'Analyzing...' }) => {
  return (
    <div className="flex items-center space-x-2">
      <div className="h-5 w-5 animate-spin rounded-full border-2 border-solid border-current border-r-transparent motion-reduce:animate-[spin_1.5s_linear_infinite]" role="status">
        <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">
          Loading...
        </span>
      </div>
      <span>{text}</span>
    </div>
  );
};

export default Loader;
