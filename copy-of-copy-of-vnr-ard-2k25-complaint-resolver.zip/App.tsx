
import React, { useState, useEffect } from 'react';
import { Complaint, FormData } from './types';
import ComplaintForm from './components/ComplaintForm';
import ComplaintList from './components/ComplaintList';
import { analyzeComplaint } from './services/geminiService';
import { CheckCircleIcon } from './components/icons';
import ThankYouMessage from './components/ThankYouMessage';

const App: React.FC = () => {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [formSubmitted, setFormSubmitted] = useState<boolean>(false);
  const [showSuccessToast, setShowSuccessToast] = useState<boolean>(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('admin') === 'true') {
      setIsAdmin(true);
    }
  }, []);

  const handleRegisterComplaint = async (data: FormData) => {
    setIsLoading(true);
    setError(null);
    try {
      const { category, severity } = await analyzeComplaint(data.description);
      
      const newComplaint: Complaint = {
        id: new Date().toISOString(),
        ...data,
        category,
        severity,
        submittedAt: new Date(),
      };

      setComplaints(prev => [newComplaint, ...prev]);
      
      if (isAdmin) {
        setShowSuccessToast(true);
        setTimeout(() => setShowSuccessToast(false), 3000);
      } else {
        setFormSubmitted(true);
      }

    } catch (err) {
      setError('Failed to process the complaint. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleResetForm = () => {
      setFormSubmitted(false);
  };

  const handleExportCSV = () => {
    if (complaints.length === 0) {
      alert("No complaints to export.");
      return;
    }

    const escapeCSV = (field: any): string => {
      const str = String(field);
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    const headers = ['ID', 'Name', 'Roll Number', 'Email', 'Phone Number', 'Description', 'Category', 'Severity', 'Submitted At'];
    const csvRows = [
      headers.join(','),
      ...complaints.map(c => [
        escapeCSV(c.id),
        escapeCSV(c.name),
        escapeCSV(c.rollNumber),
        escapeCSV(c.email),
        escapeCSV(c.phoneNumber),
        escapeCSV(c.description),
        escapeCSV(c.category),
        escapeCSV(c.severity),
        escapeCSV(c.submittedAt.toISOString()),
      ].join(','))
    ];

    const csvString = csvRows.join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    const timestamp = new Date().toISOString().split('T')[0];

    link.setAttribute('href', url);
    link.setAttribute('download', `vnr_ard_2k25_complaints_${timestamp}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };


  return (
    <div className="min-h-screen font-sans">
      <header className="bg-green-700 shadow-lg sticky top-0 z-10">
        <div className="max-w-5xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold tracking-tight text-white">
            VNR ARD 2k25 Complaint Resolver
          </h1>
          <p className="mt-1 text-green-200">Submit your issue and let our system categorize it for you.</p>
        </div>
      </header>
      
      <main className="max-w-5xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        {formSubmitted && !isAdmin ? (
            <ThankYouMessage onReset={handleResetForm} />
        ) : (
            <ComplaintForm onRegister={handleRegisterComplaint} isLoading={isLoading} />
        )}
        
        {error && <p className="text-center text-red-600 mt-4">{error}</p>}
        
        {isAdmin && (
            <div className="max-w-2xl mx-auto">
                <ComplaintList complaints={complaints} onExportCSV={handleExportCSV} />
            </div>
        )}
      </main>

      {/* Success Toast for Admin */}
      {isAdmin && (
        <div
            className={`fixed top-5 right-5 flex items-center bg-green-600 text-white text-sm font-bold px-4 py-3 rounded-lg shadow-lg transition-transform duration-300 ${
            showSuccessToast ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'
            }`}
            role="alert"
        >
            <CheckCircleIcon className="w-5 h-5 mr-2" />
            <p>Complaint registered successfully!</p>
        </div>
      )}

      <footer className="text-center py-6 text-sm text-green-800/70">
        <p>&copy; {new Date().getFullYear()} VNR ARD 2k25. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default App;
