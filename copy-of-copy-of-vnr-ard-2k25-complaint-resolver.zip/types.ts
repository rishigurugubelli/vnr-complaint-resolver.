export enum Severity {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High',
}

export interface Complaint {
  id: string;
  name: string;
  email: string;
  rollNumber: string;
  phoneNumber: string;
  description: string;
  category: string;
  severity: Severity;
  submittedAt: Date;
}

export interface FormData {
  name: string;
  email: string;
  rollNumber: string;
  phoneNumber: string;
  description: string;
}