
import { GoogleGenAI, Type } from "@google/genai";
import { Severity } from '../types';

if (!process.env.API_KEY) {
  console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    category: {
      type: Type.STRING,
      description: "Categorize the complaint into one of the following: 'Technical Issue', 'Billing Inquiry', 'Service Feedback', 'Product Question'.",
    },
    severity: {
      type: Type.STRING,
      description: "Assess the severity of the complaint as 'Low', 'Medium', or 'High'.",
    },
  },
  required: ["category", "severity"],
};

export async function analyzeComplaint(description: string): Promise<{ category: string; severity: Severity }> {
  try {
    const prompt = `
      Analyze the following user complaint and classify it.
      
      Complaint: "${description}"
      
      Based on the text, determine the most appropriate category and severity level.
      The category should be one of: 'Technical Issue', 'Billing Inquiry', 'Service Feedback', 'Product Question'.
      The severity should be one of: 'Low', 'Medium', 'High'.
      
      Return the result as a JSON object with 'category' and 'severity' keys.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    const jsonString = response.text.trim();
    const result = JSON.parse(jsonString);

    const severity = Object.values(Severity).find(s => s.toLowerCase() === result.severity.toLowerCase()) || Severity.MEDIUM;

    return {
      category: result.category || "Uncategorized",
      severity: severity,
    };
  } catch (error) {
    console.error("Error analyzing complaint with Gemini API:", error);
    // Fallback in case of API error
    return {
      category: "Uncategorized",
      severity: Severity.MEDIUM,
    };
  }
}
